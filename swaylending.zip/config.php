<?php

define('ADMIN',[			
    'DB_HOST'=>'localhost',
    'DB_USER'=>'root',
    'DB_PASSWORD'=>'123',
    'DB_NAME'=>'swaydo',    
]);

define('ROOT_DIR', dirname(__FILE__));
define('WEB_HOST', 'http://genesisblock.ddns.net/');
define('REACT_HOST', 'http://genesisblock.ddns.net:8080/app.js');
// define('REACT_HOST', 'http://genesisblock.ddns.net/swaydo/public/js/app.js');

define('COMPANY_NAME', 'SwayLending');
define('SMS_API_KEY', '46718307fab61b6bfeedf9547253f285');
define('SMS_API_SECRET', '4ef806ff6ceb4be3b69a5d92d253cfdd');